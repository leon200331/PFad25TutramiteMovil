package com.tuinsti.pfad25.tutramitemovil

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class OpcionesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_opciones)

        val cardRegistrar: CardView = findViewById(R.id.cardRegistrar)
        val cardConsultar: CardView = findViewById(R.id.cardConsultar)
        val cardRecordatorios: CardView = findViewById(R.id.cardRecordatorios)
        val cardConfig: CardView = findViewById(R.id.cardConfig)

        cardRegistrar.setOnClickListener {
            startActivity(Intent(this, RegistrarTramiteActivity::class.java))
        }

        cardConsultar.setOnClickListener {
            startActivity(Intent(this, MisTramitesActivity::class.java))
        }

        cardRecordatorios.setOnClickListener {
            startActivity(Intent(this, RecordatoriosActivity::class.java))
        }

        cardConfig.setOnClickListener {
            startActivity(Intent(this, ConfiguracionActivity::class.java))
        }
    }
}
