package com.tuinsti.pfad25.tutramitemovil


import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class RegistrarTramiteActivity : AppCompatActivity() {

    private lateinit var etNombreTramite: EditText
    private lateinit var spTipoDocumento: Spinner
    private lateinit var etFechaTramite: EditText
    private lateinit var spEstado: Spinner
    private lateinit var etNotas: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnCancelar: Button

    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar_tramite)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        etNombreTramite = findViewById(R.id.etNombreTramite)
        spTipoDocumento = findViewById(R.id.spTipoDocumento)
        etFechaTramite = findViewById(R.id.etFechaTramite)
        spEstado = findViewById(R.id.spEstado)
        etNotas = findViewById(R.id.etNotas)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnCancelar = findViewById(R.id.btnCancelar)


        val tiposDocumento = arrayOf(
            "Selecciona un tipo",
            "🆔 INE",
            "🛂 Pasaporte",
            "📄 CURP",
            "💼 RFC",
            "📋 Acta de nacimiento",
            "📝 Otro"
        )
        val adapterDoc = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tiposDocumento)
        spTipoDocumento.adapter = adapterDoc


        val estados = arrayOf("⏳ Pendiente", "🔄 En proceso", "✅ Completado")
        val adapterEstado = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, estados)
        spEstado.adapter = adapterEstado


        etFechaTramite.setOnClickListener {
            val datePicker = DatePickerDialog(
                this,
                { _, year, month, day ->
                    calendar.set(year, month, day)
                    val formato = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    etFechaTramite.setText(formato.format(calendar.time))
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.show()
        }


        btnGuardar.setOnClickListener {
            val nombre = etNombreTramite.text.toString().trim()
            val tipo = spTipoDocumento.selectedItem.toString()
            val fecha = etFechaTramite.text.toString()
            val estado = spEstado.selectedItem.toString()
            val notas = etNotas.text.toString()

            if (nombre.isEmpty() || tipo == "Selecciona un tipo" || fecha.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos obligatorios", Toast.LENGTH_SHORT).show()
            } else {
                val mensaje = """
                    ✅ Trámite guardado correctamente
                    • Nombre: $nombre
                    • Tipo: $tipo
                    • Fecha: $fecha
                    • Estado: $estado
                    • Notas: ${if (notas.isEmpty()) "Ninguna" else notas}
                """.trimIndent()
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
                limpiarCampos()
            }
        }


        btnCancelar.setOnClickListener {
            Toast.makeText(this, "Registro cancelado", Toast.LENGTH_SHORT).show()
            finish() // Cierra la pantalla
        }
    }


    private fun limpiarCampos() {
        etNombreTramite.text.clear()
        etFechaTramite.text.clear()
        etNotas.text.clear()
        spTipoDocumento.setSelection(0)
        spEstado.setSelection(0)
    }

    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
