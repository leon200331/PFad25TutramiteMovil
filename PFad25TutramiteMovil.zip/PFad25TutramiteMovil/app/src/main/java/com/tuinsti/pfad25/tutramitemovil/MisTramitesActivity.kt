package com.tuinsti.pfad25.tutramitemovil

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MisTramitesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mis_tramites)

        // Mostrar botón de regresar y título
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Mis Trámites"
    }

    // Acción del botón "regresar"
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
