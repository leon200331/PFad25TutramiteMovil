package com.tuinsti.pfad25.tutramitemovil

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.content.Intent

class RecordatoriosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordatorios)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val btnVolver: Button? = findViewById(R.id.btnVolverMenu)
        btnVolver?.setOnClickListener {

            startActivity(Intent(this, MenuActivity::class.java))
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}