package com.tuinsti.pfad25.tutramitemovil

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageView

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setCustomView(R.layout.custom_action_bar)

        val imgMenu: ImageView = findViewById(R.id.imgMenu)

        val btnEntrar: Button = findViewById(R.id.btnEntrar)
        btnEntrar.setOnClickListener {
            startActivity(Intent(this, OpcionesActivity::class.java))
        }
    }
}
